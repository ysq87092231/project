﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
namespace ImageLabeller
{
    public partial class Form1 : Form
    {
        string[] fileNames;
        public int fileIndex = -1;
        Form2 specifyIndexForm = new Form2();
        string dataSetFile = "positiveDataset.txt";
        Dictionary<string, List<Rectangle>> dataset;
        public Size imageSize = new Size(800, 480);
        UserControl1 userControl1;

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.userControl1 = new UserControl1(this);
            this.pictureBox1.Controls.Add(this.userControl1);
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutBox = new AboutBox1();
            aboutBox.ShowDialog(this);
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            gotoPictureFile(this.trackBar1.Value);
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            gotoPictureFile(0);
            while (this.fileIndex < this.fileNames.Length - 2)
                gotoPictureFile(this.fileIndex + 1);
        }

        private void 打开图片文件夹ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                this.textBox1.Text = this.folderBrowserDialog1.SelectedPath;
                this.fileNames = Directory.GetFiles(this.textBox1.Text, "*.png", SearchOption.TopDirectoryOnly);
                this.dataset = new Dictionary<string, List<Rectangle>>();

                for (int i = 0; i < this.fileNames.Length; i++)
                {
                    this.fileNames[i] = this.fileNames[i].Substring(this.fileNames[i].LastIndexOf('\\') + 1);
                    this.dataset.Add(this.fileNames[i], new List<Rectangle>());
                }
                if (this.fileNames.Length > 0)
                {
                    this.toolStripStatusLabel1.Text = "图像数量";
                    this.toolStripStatusLabel1.Text = this.fileNames.Length.ToString();
                    this.toolStripStatusLabel3.Text = "当前图像";
                    this.trackBar1.Maximum = this.fileNames.Length - 1;
                    gotoPictureFile(0);
                }
            }
        }

        private void 上一个文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.fileIndex > 0)
                this.gotoPictureFile(this.fileIndex - 1);
        }

        private void 下一个文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.fileIndex < this.fileNames.Length - 2)
                this.gotoPictureFile(this.fileIndex + 1);
        }

        private void 指定帧ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.specifyIndexForm.ShowDialog() == DialogResult.OK)
            {
                if ((this.specifyIndexForm.index >= 0) && (this.specifyIndexForm.index < this.fileNames.Length))
                {
                    gotoPictureFile(this.specifyIndexForm.index);
                    return;
                }
                else
                {
                    for (int i = 0; i < this.fileNames.Length; i++)
                        if (this.fileNames[i].CompareTo(this.specifyIndexForm.fileName) == 0)
                        {
                            gotoPictureFile(i);
                            return;
                        }
                }
                MessageBox.Show("无法跳转到指定帧。");
            }
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            saveDataSet();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.dataSetFile = this.saveFileDialog1.FileName;
                saveDataSet();
            }
        }

        public void ShowMouseStatus(Point point)
        {
            if (point.X >= 0)
                this.toolStripStatusLabel6.Text = " 鼠标坐标：(" + point.X + ", " + point.Y + ") ";
            else this.toolStripStatusLabel6.Text = " 鼠标坐标：(-, -) ";
        }

        private void saveDataSet()
        {
            FileStream oStream = new FileStream(this.dataSetFile, FileMode.Create);
            StreamWriter writer = new StreamWriter(oStream);
            foreach (string fileName in this.dataset.Keys)
                if (this.dataset[fileName].Count > 0)
                {
                    List<Rectangle> rects = this.dataset[fileName];
                    writer.Write(fileName + " " + rects.Count + " ");
                    foreach (Rectangle rect in rects)
                        writer.Write(rect.X + " " + rect.Y + " " + rect.Width + " " + rect.Height+" ");
                    writer.WriteLine();
                }
            writer.Close();
            oStream.Close();
        }

        private void loadDataSet()
        {
            foreach (List<Rectangle> rects in this.dataset.Values)
                rects.Clear();
            FileStream inStream = new FileStream(this.dataSetFile, FileMode.Open);
            StreamReader reader = new StreamReader(inStream);
            char[] splitter = { ' ', '\t' };
            string st = reader.ReadLine();
            while (st!=null)
            {
                string[] strArr = st.Trim().Split(splitter);
                if (this.dataset.ContainsKey(strArr[0].Trim()))
                {
                    List<Rectangle> rects = this.dataset[strArr[0].Trim()];
                    int count = Int32.Parse(strArr[1]);
                    int k = 2;
                    for (int i = 0; i < count; i++)
                    {
                        rects.Add(new Rectangle(Int32.Parse(strArr[k]), Int32.Parse(strArr[k + 1]), Int32.Parse(strArr[k + 2]), Int32.Parse(strArr[k + 3])));
                        k += 4;
                    }
                }
                st = reader.ReadLine();
            }
            reader.Close();
            inStream.Close();
            this.userControl1.pictureChanged(this.dataset[this.fileNames[this.fileIndex]]);
        }

        private void gotoPictureFile(int index)
        {
            this.fileIndex = index;
            this.trackBar1.Value = index;
            this.toolStripStatusLabel4.Text = index.ToString();
            this.textBox2.Text = this.fileNames[index];
            this.pictureBox1.Image = Image.FromFile(this.textBox1.Text + "\\" + this.textBox2.Text);
            this.userControl1.pictureChanged(this.dataset[this.fileNames[index]]);
        }

        private void saveDatasetAsPictures(string folder)
        {
            int count=0;
            foreach (string filename in this.dataset.Keys)
                if (this.dataset[filename].Count > 0)
                {
                    Bitmap image = (Bitmap)Bitmap.FromFile(this.textBox1.Text + "\\" + filename);
                    foreach (Rectangle rect in this.dataset[filename])
                    {
                        Rectangle rectAdjust = rect;
                        if (rectAdjust.X < 0) rectAdjust.X = 0;
                        if (rectAdjust.Y < 0) rectAdjust.Y = 0;
                        if (rectAdjust.Width + rectAdjust.X >= this.imageSize.Width)
                            rectAdjust.Width = this.imageSize.Width - rectAdjust.X;
                        if (rectAdjust.Height + rectAdjust.Y >= this.imageSize.Height)
                            rectAdjust.Height = this.imageSize.Height - rectAdjust.Y;
                        Image tmpImage = image.Clone(rectAdjust, image.PixelFormat);
                        tmpImage.Save(folder + "\\activeBackground_" + count + ".jpg");
                        count++;
                        tmpImage.Dispose();
                    }
                    image.Dispose();
                }    
        }

        private void 打开数据集ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.fileIndex < 0)
            {
                MessageBox.Show("请先打开一个图片文件夹，再打开数据集。","操作顺序错误");
                return;
            }
            if (MessageBox.Show("打开其他数据集将清空当前未保存的标注数据，是否继续？","警告",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.dataSetFile = this.openFileDialog1.FileName;
                loadDataSet();
            }
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            if (this.fileIndex < 0)
            {
                MessageBox.Show("请先打开一个图片文件夹，再打开数据集。", "操作顺序错误");
                return;
            }
            if (this.folderBrowserDialog2.ShowDialog() == DialogResult.OK)
            {
                saveDatasetAsPictures(this.folderBrowserDialog2.SelectedPath);
            }
        }

    }
}
