﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ImageLabeller
{
    public partial class UserControl1 :Label
    {
        List<Rectangle> boxesToDraw=new List<Rectangle>();
        Pen normalPen = new Pen(System.Drawing.Color.Blue, 1), specialPen = new Pen(System.Drawing.Color.Red, 1);
        Point startPoint;
        Rectangle mouseRect;
        bool isMouseDown=false;
        Form1 form;
        bool isFirstDrawRound = true;
        public UserControl1()
        {
            InitializeComponent();
        }
        public UserControl1(Form1 form)
        {
            this.DoubleBuffered = true;
            this.form = form;
            InitializeComponent();
            this.Size = form.imageSize;
            this.BackColor = Color.Transparent;
        }

        void UserControl1_MouseLeave(object sender, EventArgs e)
        {
            this.form.ShowMouseStatus(new Point(-1,-1));
        }

        public void pictureChanged(List<Rectangle> boxesToDraw)
        {
            if (this.isFirstDrawRound)
            {
                this.isFirstDrawRound = false;
                this.MouseDown += new MouseEventHandler(UserControl1_MouseDown);
                this.MouseUp += new MouseEventHandler(UserControl1_MouseUp);
                this.MouseMove += new MouseEventHandler(UserControl1_MouseMove);
                this.MouseClick += new MouseEventHandler(UserControl1_MouseClick);
                this.MouseLeave += new EventHandler(UserControl1_MouseLeave);
            }
            this.boxesToDraw = boxesToDraw;
            this.Refresh();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            foreach(Rectangle rect in this.boxesToDraw)
                e.Graphics.DrawRectangle(this.normalPen, rect);
            if (this.isMouseDown)
                e.Graphics.DrawRectangle(specialPen, this.mouseRect);
        }

        private void UserControl1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.isMouseDown = true;
                this.startPoint = e.Location;
                this.mouseRect = getRect(startPoint, e.Location);
                this.Refresh();
            }
        }

        private void UserControl1_MouseMove(object sender, MouseEventArgs e)
        {
            this.form.ShowMouseStatus(e.Location);
            if (this.isMouseDown)
            {
                this.mouseRect = getRect(this.startPoint, e.Location);
                this.Refresh();
            }
        }

        private void UserControl1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                if (this.isMouseDown)
                {
                    this.isMouseDown = false;
                    if ((this.mouseRect.Width >= 5) && (this.mouseRect.Height >= 5))
                        this.boxesToDraw.Add(this.mouseRect);
                    this.Refresh();
                }
        }

        private void UserControl1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                foreach (Rectangle rect in this.boxesToDraw)
                    if (rect.Contains(e.Location))
                    {
                        this.boxesToDraw.Remove(rect);
                        this.Refresh();
                        return;
                    }
            }
        }
        
        private Rectangle getRect(Point p1, Point p2)
        {
            int x = (p1.X < p2.X) ? p1.X : p2.X;
            int y = (p1.Y < p2.Y) ? p1.Y : p2.Y;
            int width = (p1.X > p2.X) ? (p1.X - p2.X) : (p2.X - p1.X);
            int height = (p1.Y > p2.Y) ? (p1.Y - p2.Y) : (p2.Y - p1.Y);
            return new Rectangle(x, y, width, height);
        }
    }
}
