﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageLabeller
{
    public partial class CustomPanel : Label
    {
        public CustomPanel()
        {
            InitializeComponent();
            this.Size = new Size(100, 100);
            this.BackColor = Color.Transparent;

//            this.Paint = new System.Windows.Forms.PaintEventHandler(this.CustomPanel_Paint);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            //e.Graphics.TranslateTransform(this.AutoScrollPosition.X, this.AutoScrollPosition.Y);
//            e.Graphics.Clear(Color.Transparent);
            
            Pen myPen = new Pen(System.Drawing.Color.Red, 5);

            Rectangle myRectangle = new Rectangle(20, 20, 250, 200);

            e.Graphics.DrawRectangle(myPen, myRectangle);
            //base.OnPaint(e);
        }
 
/*        private void CustomPanel_Paint(object sender, PaintEventArgs e)
        {
            Pen myPen = new Pen(System.Drawing.Color.Red, 5);

            Rectangle myRectangle = new Rectangle(20, 20, 250, 200);

            e.Graphics.DrawRectangle(myPen, myRectangle);
        }
 */
    }
}
